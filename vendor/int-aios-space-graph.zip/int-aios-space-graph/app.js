const canvas=document.querySelector('#graph'),ctx=canvas.getContext('2d');
const $=s=>document.querySelector(s),reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;
const nodes=[
 {name:'INT AIOS',color:'#79beff',p:[0,0,0]},
 {name:'客厅',color:'#6bbcff',p:[-220,-155,65]},
 {name:'卧室',color:'#9fa0ff',p:[75,-235,-65]},
 {name:'卫生间',color:'#aa8aff',p:[265,-155,30]},
 {name:'厨房',color:'#60cfc9',p:[310,40,-40]},
 {name:'餐厅',color:'#73d1d1',p:[190,205,90]},
 {name:'书房',color:'#b394ff',p:[-55,245,-10]},
 {name:'阳台',color:'#82aaff',p:[-255,160,50]},
 {name:'玄关',color:'#73b6ed',p:[-310,-10,-80]}
];
nodes.forEach(n=>{n.base=[...n.p];n.target=[...n.p]});
let w,h,dpr,unit,ox,oy,angleY=.12,angleX=-.16,zoom=1,time=0,last=0,paused=reduced,rotating=false,selected=0,hover=-1,drag=null,light=false,points=[];
const stars=Array.from({length:95},(_,i)=>({x:Math.sin(i*137.5)*.48,y:Math.cos(i*49.7)*.46,z:Math.sin(i*13.7),r:i%4===0?1.5:.65}));
function resize(){w=canvas.clientWidth;h=canvas.clientHeight;dpr=Math.min(devicePixelRatio||1,2);canvas.width=w*dpr;canvas.height=h*dpr;ctx.setTransform(dpr,0,0,dpr,0,0);unit=Math.min(w*.88/760,h*.75/610);ox=w*.5;oy=h*.46}
addEventListener('resize',resize);resize();
function rotate(p){const [x,y,z]=p,cy=Math.cos(angleY),sy=Math.sin(angleY),cx=Math.cos(angleX),sx=Math.sin(angleX),xx=x*cy+z*sy,zz=-x*sy+z*cy;return [xx,y*cx-zz*sx,y*sx+zz*cx]}
function project(p){const [x,y,z]=rotate(p),s=850/(850+z)*unit*zoom;return{x:ox+x*s,y:oy+y*s,z,s}}
function rgba(hex,a){return `rgba(${parseInt(hex.slice(1,3),16)},${parseInt(hex.slice(3,5),16)},${parseInt(hex.slice(5,7),16)},${a})`}
function circle(x,y,r,color){ctx.beginPath();ctx.arc(x,y,Math.max(.1,r),0,Math.PI*2);ctx.fillStyle=color;ctx.fill()}
function hex(x,y,r,spin){ctx.beginPath();for(let j=0;j<6;j++){const a=j*Math.PI/3+spin;const px=x+Math.cos(a)*r,py=y+Math.sin(a)*r;j?ctx.lineTo(px,py):ctx.moveTo(px,py)}ctx.closePath()}
function path(a,b,t){const bend=Math.sin(t*Math.PI)*13*unit;return{x:a.x+(b.x-a.x)*t,y:a.y+(b.y-a.y)*t+bend}}
function draw(ts){const dt=Math.min((ts-last)/1000||0,.04);last=ts;if(!paused){time+=dt;if(rotating&&!drag)angleY+=dt*.10}nodes.forEach(n=>n.p=n.p.map((v,k)=>v+(n.target[k]-v)*Math.min(1,dt*15)));ctx.clearRect(0,0,w,h);
 const aura=ctx.createRadialGradient(ox,oy,10,ox,oy,Math.max(1,380*unit));aura.addColorStop(0,light?'rgba(76,143,229,.07)':'rgba(24,64,118,.16)');aura.addColorStop(1,'transparent');ctx.fillStyle=aura;ctx.fillRect(0,0,w,h);
 stars.forEach((s,i)=>{const x=ox+s.x*w+Math.sin(time*.08+s.z)*5,y=oy+s.y*h;circle(x,y,s.r,light?`rgba(51,90,144,${.10+s.r*.045})`:`rgba(115,165,221,${.12+s.r*.1})`)});
 // Perspective orbital guides: visual guides only, no additional entity nodes.
 for(let ring=0;ring<2;ring++){ctx.beginPath();for(let j=0;j<=120;j++){const a=j/120*Math.PI*2,p=project([Math.cos(a)*(350+ring*25),Math.sin(a)*(275+ring*20),-20]);j?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y)}ctx.strokeStyle=light?'#40608812':'#8cadde0c';ctx.setLineDash(ring?[2,9]:[2,5]);ctx.lineWidth=1;ctx.stroke();ctx.setLineDash([])}
 points=nodes.map((n,i)=>{const bob=i===0||drag?.index===i?0:Math.sin(time*1.15+i*.78)*7;return project([n.p[0],n.p[1]+bob,n.p[2]])});
 for(let i=1;i<nodes.length;i++){const a=points[0],b=points[i],active=selected===i||hover===i,c=nodes[i].color;ctx.beginPath();for(let j=0;j<=50;j++){const p=path(a,b,j/50);j?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y)}ctx.strokeStyle=rgba(c,light?(active?.75:.38):(active?.8:.3));ctx.lineWidth=active?1.5:1;ctx.stroke();for(let k=0;k<3;k++){const t=(time*(.14+i*.007)+k/3+i*.11)%1;for(let j=16;j>=0;j--){const tt=t-j*.006;if(tt<0)continue;const p=path(a,b,tt);circle(p.x,p.y,(j===0?2.5:1.4)*Math.max(.6,unit),rgba(c,(1-j/17)*(active?1:.8)))}const p=path(a,b,t);ctx.shadowBlur=12;ctx.shadowColor=c;circle(p.x,p.y,1.4,light?c:'#e4f6ff');ctx.shadowBlur=0}}
 [...nodes.keys()].sort((a,b)=>points[b].z-points[a].z).forEach(i=>{const n=nodes[i],p=points[i],core=i===0,active=selected===i||hover===i,r=(core?25:10)*Math.max(.6,p.s),c=n.color,glowScale=1+Math.sin(time*1.8+i*.74)*.18,glowRadius=r*(core?4:3.5)*glowScale,glow=ctx.createRadialGradient(p.x,p.y,0,p.x,p.y,glowRadius);glow.addColorStop(0,rgba(c,light?.24:.35));glow.addColorStop(.4,rgba(c,light?.09:.14));glow.addColorStop(1,rgba(c,0));ctx.fillStyle=glow;ctx.fillRect(p.x-glowRadius,p.y-glowRadius,glowRadius*2,glowRadius*2);
 ctx.strokeStyle=rgba(c,active?.6:.25);ctx.lineWidth=1;ctx.beginPath();ctx.arc(p.x,p.y,r*(core?1.65:1.9),0,Math.PI*2);ctx.stroke();hex(p.x,p.y,r*1.4,-Math.PI/2);ctx.fillStyle=rgba(c,light?.08:.1);ctx.fill();ctx.strokeStyle=rgba(c,.65);ctx.stroke();ctx.shadowBlur=core?22:14;ctx.shadowColor=c;hex(p.x,p.y,r,-Math.PI/2);const g=ctx.createLinearGradient(p.x-r,p.y-r,p.x+r,p.y+r);g.addColorStop(0,light?'#def2ff':'#dcf7ff');g.addColorStop(.4,c);g.addColorStop(1,core?'#397cdd':c);ctx.fillStyle=g;ctx.fill();ctx.shadowBlur=0;if(core){hex(p.x,p.y,r*.48,-Math.PI/2);ctx.fillStyle=light?'#f7fcff':'#d9faff';ctx.fill()}
 const font=core?13:12,labelY=p.y+r*(core?2.05:2.6);ctx.font=`${core?500:400} ${font}px "Avenir Next", "PingFang SC", sans-serif`;ctx.textAlign='center';ctx.fillStyle=light?'#233950':'#e2eafa';ctx.fillText(n.name,p.x,labelY+9);
 });requestAnimationFrame(draw)}
function select(i){selected=i}
function hit(x,y){return points.map((p,i)=>({i,d:Math.hypot(p.x-x,p.y-y),z:p.z})).filter(p=>p.d<(p.i===0?37:24)*Math.max(.65,points[p.i].s)).sort((a,b)=>a.z-b.z)[0]?.i??-1}
function local(e){const r=canvas.getBoundingClientRect();return{x:e.clientX-r.left,y:e.clientY-r.top}}
canvas.addEventListener('pointerdown',e=>{if(drag)return;const p=local(e),i=hit(p.x,p.y);drag={index:i,x:p.x,y:p.y,id:e.pointerId};if(i>=0)select(i);canvas.setPointerCapture(e.pointerId);canvas.style.cursor='grabbing'});
canvas.addEventListener('pointermove',e=>{const p=local(e);if(!drag){hover=hit(p.x,p.y);canvas.style.cursor=hover>=0?'pointer':'grab';return}if(e.pointerId!==drag.id)return;const dx=p.x-drag.x,dy=p.y-drag.y;if(drag.index>=0){const i=drag.index,s=points[i].s,cy=Math.cos(angleY),sy=Math.sin(angleY),cx=Math.cos(angleX),sx=Math.sin(angleX);nodes[i].target[0]+=cy*dx/s+sy*sx*dy/s;nodes[i].target[1]+=cx*dy/s;nodes[i].target[2]+=sy*dx/s-cy*sx*dy/s}else{angleY+=dx*.005;angleX=Math.max(-1.15,Math.min(1.15,angleX+dy*.005))}drag.x=p.x;drag.y=p.y});
function end(){drag=null;canvas.style.cursor='grab'}canvas.addEventListener('pointerup',end);canvas.addEventListener('pointercancel',end);canvas.addEventListener('lostpointercapture',end);canvas.addEventListener('pointerleave',()=>hover=-1);
function setZoom(z){zoom=Math.max(.55,Math.min(1.8,z));$('#zoom').textContent=Math.round(zoom*100)+'%'}canvas.addEventListener('wheel',e=>{e.preventDefault();setZoom(zoom*Math.exp(-e.deltaY*.001))},{passive:false});$('#plus').onclick=()=>setZoom(zoom+.1);$('#minus').onclick=()=>setZoom(zoom-.1);
function setTheme(value){light=value==='light';document.documentElement.dataset.theme=value;$('#dark').setAttribute('aria-pressed',!light);$('#light').setAttribute('aria-pressed',light)}$('#dark').onclick=()=>setTheme('dark');$('#light').onclick=()=>setTheme('light');
$('#rotate').onclick=()=>{rotating=!rotating;$('#rotate').setAttribute('aria-pressed',rotating)};
function pause(){document.body.classList.toggle('paused',paused);$('#pause').setAttribute('aria-pressed',paused);$('#pause').textContent=paused?'▷ 继续':'Ⅱ 暂停'}$('#pause').onclick=()=>{paused=!paused;pause()};pause();
$('#reset').onclick=()=>{nodes.forEach(n=>n.target=[...n.base]);angleX=-.16;angleY=.12;setZoom(1);rotating=false;$('#rotate').setAttribute('aria-pressed',false);select(0)};
requestAnimationFrame(draw);
