# INT AIOS 动态空间关系图谱

本包包含当前确认版本，使用原生 HTML / JavaScript / Canvas，无第三方库、图片、外部字体或网络接口依赖。

## 文件

- `index.html`：图谱页面、样式和基础控制按钮。
- `app.js`：节点数据、三维透视投影、拖拽、视角旋转、缩放和动画。
- `embed-example.html`：在已有前端页面中嵌入图谱的完整示例。

运行图谱只需要 `index.html` 和 `app.js`，保持二者在同一目录。

## 推荐接入方式：iframe

将整个文件夹复制到前端项目的静态资源目录，例如 Vite、React、Vue 或 Next.js 的 `public/int-aios-space-graph/`。在页面中加入：

```html
<iframe
  src="/int-aios-space-graph/index.html"
  title="INT AIOS 空间关系图谱"
  style="display:block;width:100%;height:600px;border:0;border-radius:16px;"
  loading="lazy"
></iframe>
```

React 中将 `style` 改为对象：

```jsx
<iframe
  src="/int-aios-space-graph/index.html"
  title="INT AIOS 空间关系图谱"
  style={{ display: 'block', width: '100%', height: 600, border: 0, borderRadius: 16 }}
  loading="lazy"
/>
```

部署在网站子路径时，请按实际静态资源路径修改 `src`。iframe 会隔离图谱的全屏样式和按钮 ID，适合直接插入已有页面。图谱自动适应 iframe 的尺寸；建议高度不小于 420px。

默认显示黑色背景，通过图谱右上角切换黑白主题。主题目前由图谱内部控制，不自动跟随宿主页面主题。

## 当前效果

中心节点为 INT AIOS；外围 8 个节点为客厅、卧室、卫生间、厨房、餐厅、书房、阳台、玄关。

中心节点无自动浮动或本体缩放；外围节点上下浮动；所有节点光晕呼吸扩张。节点文字无背景底板。连接线有流光粒子效果，表现为视觉动画，未连接真实设备或数据接口。

支持拖动节点、拖动空白旋转视角、滚轮缩放，以及自动旋转、暂停和重置。操作引起的视角或透视缩放仍会改变显示位置与大小。

## 修改节点与动画

在 `app.js` 的 `nodes` 数组中修改：

```js
{ name: '客厅', color: '#6bbcff', p: [-220, -155, 65] }
```

`name` 是名称，`color` 是颜色，`p` 是三维位置 `[x, y, z]`。数组第一个元素为中心节点，其余节点分别与中心相连。

- 外围上下浮动：`bob` 表达式中的 `7` 控制幅度，`1.15` 控制速度。
- 光晕呼吸：`glowScale` 表达式中的 `.18` 控制扩张幅度，`1.8` 控制速度。
- 流光速度：连线动画中的 `time*(.14+i*.007)`。

## 本地查看

可以直接打开 `index.html`，或在本文件夹启动静态服务：

```sh
python3 -m http.server 5198 --bind 127.0.0.1
```

访问 `http://127.0.0.1:5198/` 查看图谱，访问 `/embed-example.html` 查看嵌入示例。

建议使用近期版本的 Chrome、Edge、Safari 或 Firefox。系统开启减少动态效果时，页面默认暂停，仍可通过“继续”启动动画。
